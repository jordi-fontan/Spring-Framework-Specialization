package com.student.controller;

 
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
//TODO
//TODO
public class StudentController {
	
	 
	private String message;
 
	
 
	public String getMessage() {
		return message;
	}
	
 

}
